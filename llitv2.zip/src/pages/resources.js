import React from 'react'

function resources() {
    return (
        <div>
            <h1>THIS IS THE RESOURCES PAGE</h1>
        </div>
    )
}

export default resources
