import React from 'react'

function mediaAndpress() {
    return (
        <div>
            <h1>THIS IS THE MEDIA AND PRESS PAGE</h1>
        </div>
    )
}

export default mediaAndpress
