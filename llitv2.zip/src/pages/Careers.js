import React from 'react'

function Careers() {
    return (
        <div>
            <h1>THIS IS THE CAREERS PAGE</h1>
        </div>
    )
}

export default Careers
