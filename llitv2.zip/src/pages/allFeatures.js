import React from 'react'

function allFeatures() {
    return (
        <div>
            <h1>THIS IS ALL FEATURES PAGE</h1>
        </div>
    )
}

export default allFeatures
