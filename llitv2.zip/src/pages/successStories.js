import React from 'react'

function successStories() {
    return (
        <div>
            <h1>THIS IS SUCCESS STORIES PAGE</h1>
        </div>
    )
}

export default successStories
