import React from 'react'

function blog() {
    return (
        <div>
            <h1>THIS IS THE BLOG PAGE</h1>
        </div>
    )
}

export default blog
