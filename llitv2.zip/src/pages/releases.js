import React from 'react'

function releases() {
    return (
        <div>
            <h1>THIS IS RELEASES PAGE</h1>
        </div>
    )
}

export default releases
