import React from 'react'
import "./Videobox.css"
import { useState } from 'react';
import { Button } from '../ButtonElements';

function Videobox() {

    const [check, setCheck] = useState(0)

    const handleCheckone = (() => {
        console.log({ check })
        setCheck(0)
    })

    const handleChecktwo = (() => {
        console.log({ check })
        setCheck(1)
    })

    const handleCheckthree = (() => {
        console.log({ check })
        setCheck(2)
    })

    return (
        <div className="video_wrapper">
            <div className="video_text">
                <h3>
                    Start a discourse around <br />core topics
                    <br />
                    <br />
                </h3>
                <p>
                    It’s simple to both host and watch your event <br />content. Your attendees can jump straight into the <br />stream as soon as they join, or start networking 1:1 <br />with others. And with multiple livestream hosting, <br />live chat, breakout rooms and more, it’s simple to <br />provide access to the content your audience <br />demands.
                </p>


                <div>
                    <button onClick={handleCheckone}>
                        MULTIPLE LIVE STREAMS
                    </button>
                </div>
                <div>
                    <button onClick={handleChecktwo}>
                        LIVE STREAM QUESTIONS
                    </button>
                </div>
                <div>
                    <button onClick={handleCheckthree}>
                        BREAKOUT ROOMS
                    </button>
                </div>
            </div>
            {check === 0 ? <div className="video_vid">
                <video width="400" height="250  " loop autoPlay>
                    <source src="https://f.hubspotusercontent00.net/hubfs/2090809/Animations/Multiple_Livestreams.mp4"></source>

                </video>
            </div> : ""
            }
            {
                check === 1 ? <div className="video_vid">
                    <video width="400" height="250  " loop autoPlay>
                        <source src="https://f.hubspotusercontent00.net/hubfs/2090809/Animations/Stream_Chat_Q&A.mp4"></source>

                    </video>
                </div> : ""
            }
            {
                check === 2 ? <div className="video_vid">
                    <video width="400" height="250  " loop autoPlay>
                        <source src="https://f.hubspotusercontent00.net/hubfs/2090809/Animations/Breakout_room.mp4"></source>

                    </video>
                </div> : ""
            }

        </div>
    )
}

export default Videobox

