import React, { useState } from 'react';
import Navbar from '../components/Navbar';
import Sidebar from '../components/Sidebar';
import Footer from '../components/Footer';
import InfoSection from '../components/InfoSection';
import ScrollToTop from '../components/ScrollToTop';
import Carousel from '../components/InfoSection/carosel';
import Reviews from '../components/InfoSection/Reviews';
import Videobox from '../components/InfoSection/Videobox';
import {
  virtualObjOne,
  virtualObjTwo,
  virtualObjThree,
  virtualObjFour,
  virtualObjFive
} from '../components/InfoSection/Data';

function Virtual() {
  const [isOpen, setIsOpen] = useState(false);

  const toggle = () => {
    setIsOpen(!isOpen);
  };
  return (
    <>
      <ScrollToTop />
      <Sidebar isOpen={isOpen} toggle={toggle} />
      <Navbar toggle={toggle} />
      <Videobox />
      <InfoSection {...virtualObjOne} />
      <Carousel></Carousel>
      <InfoSection {...virtualObjFive} />
      <InfoSection {...virtualObjTwo} />
      <InfoSection {...virtualObjFour} />
      <InfoSection {...virtualObjThree} />

      <Footer />
    </>
  );
}

export default Virtual;
